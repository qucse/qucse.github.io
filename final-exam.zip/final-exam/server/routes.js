const express = require('express');
const router = express.Router();

const heroService = require('./services/HifzService');

//Heroes Web API
router.route('/surahs')
    .get( heroService.getSurahs );

module.exports = router;