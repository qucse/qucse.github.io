const Surah = require('./SurahModel');

class HifzRepository {

    async initDb() {
        //If the surahs collections is empty then init the db with surahs.json
        //Uncomment the line below to empty Surahes collection and re-init DB
        await Surah.remove({});
        const surahsCount = await this.getSurahsCount();
        console.log('Number of existing surahs:', surahsCount);
        if (surahsCount === 0) {
            await this.loadFromJsonFile();
        }
    }

    async loadFromJsonFile() {
        const fs = require('fs-extra');
        const path = require('path');
        const surahFilePath = path.join(__dirname, '../data/surah.json' );
        const  surahs = await fs.readJson(surahFilePath);

        for (let surah of surahs) {
            await this.addSurah(surah);
        }
    }

    getSurahs() {
        return Surah.find({});
    }

    addSurah(newSurah) {
        return Surah.create(newSurah);
    }

    getSurahsCount() {
        return Surah.count({});
    }
}

module.exports = new HifzRepository();