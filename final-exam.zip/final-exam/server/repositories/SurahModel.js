const mongoose = require('mongoose');

const surahSchema = new mongoose.Schema({
    id: Number,
    name: String,
    englishName: String,
    ayaCount: Number,
    type: String
});

module.exports = mongoose.model('Surah', surahSchema);
