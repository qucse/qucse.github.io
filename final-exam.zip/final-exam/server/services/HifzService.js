const heroRepository = require('../repositories/HifzRepository');

class HifzService {

    //You can test this by visiting http://localhost:4040/api/surahs
    async getSurahs(req, res) {
        try {
            const heroes = await heroRepository.getSurahs();
            res.json(heroes);
        } catch (err) {
            console.log(err);
            res.status(500).send(err);
        }
    }
}

module.exports = new HifzService();