# Install vue-cli
npm install -g @vue/cli

# Create project
vue create client
(accept the 1st option (simple-app) by pressing enter)
=> This will install all the dependencies and the required tools

# To run the server
cd server
node app.js

# To run the client
cd client
npm run serve
