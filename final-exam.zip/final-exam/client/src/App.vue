<template>
  <main class="container">
      <h3>
        {{title}}
      </h3>
      <router-view/>
  </main>
</template>

<script>
    export default {
        data() {
            return {
                title: 'Hifz App'
            }
        },
        methods: {
        }
    }
</script>

<style>
  @import '../node_modules/bootstrap/dist/css/bootstrap.css';
  @import url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');

  #container {
    text-align: center;
  }
</style>
